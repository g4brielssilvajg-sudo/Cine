# Cine Livre — projeto inicial Android

Aplicativo Android de catálogo de filmes e séries de domínio público, sem anúncios e sem assinatura.

## O que já está incluído
- Interface escura inspirada em serviços de streaming, com identidade própria.
- Catálogo local de exemplo, pesquisa e filtros por categoria.
- Tela de detalhes e player de vídeo usando links de exemplo.
- Lista de favoritos mantida em memória durante a sessão.
- Sem SDK de anúncios, login, assinatura ou rastreamento.

> Os vídeos do catálogo de exemplo são demonstrações públicas do Internet Archive. Antes de publicar, confirme a licença e a disponibilidade de cada título na sua região. “Estar na internet” não significa automaticamente que uma obra seja de domínio público.

## Requisitos
- Android Studio recente
- JDK 17
- Android SDK instalado (compile SDK 35 ou compatível)

## Abrir e executar
1. Extraia o ZIP.
2. Abra a pasta `CineLivre` no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Conecte um Android com depuração USB habilitada ou crie um emulador.
5. Pressione **Run**.

## Gerar APK
No Android Studio: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
O APK de depuração costuma aparecer em `app/build/outputs/apk/debug/app-debug.apk`.

## Observações
- O primeiro build precisa de internet para baixar as dependências do Gradle.
- Os links do catálogo são exemplos; podem mudar ou deixar de funcionar.
- Para lançar publicamente, adicione uma política de privacidade se passar a coletar dados, valide direitos/licenças e teste em aparelhos reais.
