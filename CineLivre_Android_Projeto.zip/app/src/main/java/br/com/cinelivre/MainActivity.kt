package br.com.cinelivre

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var list: LinearLayout
    private lateinit var search: EditText
    private var selectedCategory = "Todos"
    private val favorites = mutableSetOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(16, 16, 16)
        window.navigationBarColor = Color.rgb(16, 16, 16)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(12), dp(18), dp(16))
            setBackgroundColor(Color.rgb(16, 16, 16))
        }
        val brand = TextView(this).apply {
            text = "CINE LIVRE"
            textSize = 27f
            setTextColor(Color.rgb(229, 9, 20))
            setTypeface(null, Typeface.BOLD)
        }
        root.addView(brand)
        root.addView(TextView(this).apply {
            text = "Filmes para assistir gratuitamente"
            textSize = 14f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(2), 0, dp(14))
        })

        search = EditText(this).apply {
            hint = "Buscar filme ou gênero"
            setSingleLine(true)
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            setPadding(dp(12), 0, dp(12), 0)
            setBackgroundColor(Color.rgb(42, 42, 42))
        }
        root.addView(search, LinearLayout.LayoutParams(-1, dp(48)))

        val categories = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        listOf("Todos", "Terror", "Comédia", "Aventura", "Fantasia").forEach { category ->
            val button = Button(this).apply {
                text = category
                textSize = 10f
                isAllCaps = false
                setOnClickListener {
                    selectedCategory = category
                    render()
                }
            }
            categories.addView(button, LinearLayout.LayoutParams(0, dp(44), 1f))
        }
        root.addView(categories)

        val scroller = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroller.addView(list)
        root.addView(scroller, LinearLayout.LayoutParams(-1, 0, 1f))
        search.addTextChangedListener(SimpleTextWatcher { render() })
        setContentView(root)
        render()
    }

    private fun render() {
        if (!::list.isInitialized) return
        list.removeAllViews()
        val query = search.text.toString().trim()
        val filtered = Catalog.items.filter {
            (selectedCategory == "Todos" || it.category == selectedCategory) &&
            (it.title.contains(query, true) || it.category.contains(query, true))
        }
        if (filtered.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "Nenhum título encontrado."
                setTextColor(Color.WHITE)
                setPadding(0, dp(24), 0, 0)
            })
        }
        filtered.forEach { movie ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(dp(12), dp(14), dp(12), dp(14))
                setBackgroundColor(Color.rgb(30, 30, 30))
            }
            val art = TextView(this).apply {
                text = movie.posterEmoji
                textSize = 42f
                gravity = Gravity.CENTER
            }
            card.addView(art, LinearLayout.LayoutParams(dp(82), dp(100)))
            val info = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(10), 0, 0, 0)
            }
            info.addView(TextView(this).apply {
                text = movie.title
                textSize = 17f
                setTypeface(null, Typeface.BOLD)
                setTextColor(Color.WHITE)
            })
            info.addView(TextView(this).apply {
                text = "${movie.year}  •  ${movie.category}"
                textSize = 12f
                setTextColor(Color.LTGRAY)
                setPadding(0, dp(4), 0, dp(8))
            })
            val open = Button(this).apply {
                text = "Ver detalhes"
                isAllCaps = false
                setOnClickListener {
                    startActivity(Intent(this@MainActivity, DetailsActivity::class.java)
                        .putExtra("title", movie.title))
                }
            }
            info.addView(open)
            card.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
            val params = LinearLayout.LayoutParams(-1, -2)
            params.setMargins(0, dp(10), 0, 0)
            list.addView(card, params)
        }
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
