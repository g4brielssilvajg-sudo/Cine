package br.com.cinelivre

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class DetailsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val title = intent.getStringExtra("title") ?: Catalog.items.first().title
        val movie = Catalog.items.firstOrNull { it.title == title } ?: Catalog.items.first()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 32, 24, 24)
            setBackgroundColor(Color.rgb(16, 16, 16))
        }
        root.addView(TextView(this).apply {
            text = movie.posterEmoji
            textSize = 88f
        })
        root.addView(TextView(this).apply {
            text = movie.title
            textSize = 26f
            setTextColor(Color.WHITE)
        })
        root.addView(TextView(this).apply {
            text = "${movie.year} • ${movie.category}"
            textSize = 14f
            setTextColor(Color.LTGRAY)
            setPadding(0, 8, 0, 18)
        })
        root.addView(TextView(this).apply {
            text = movie.synopsis + "\n\nNota de direitos: " + movie.publicDomainNote
            textSize = 16f
            setTextColor(Color.WHITE)
        })
        root.addView(Button(this).apply {
            text = "▶ Assistir"
            isAllCaps = false
            setOnClickListener {
                startActivity(Intent(this@DetailsActivity, PlayerActivity::class.java)
                    .putExtra("title", movie.title))
            }
        })
        root.addView(Button(this).apply {
            text = "Voltar"
            isAllCaps = false
            setOnClickListener { finish() }
        })
        setContentView(root)
    }
}
