package br.com.cinelivre

data class Movie(
    val title: String,
    val year: String,
    val category: String,
    val synopsis: String,
    val videoUrl: String,
    val posterEmoji: String,
    val publicDomainNote: String
)

object Catalog {
    // URLs de demonstração; valide a licença/estado de domínio público antes de distribuir.
    val items = listOf(
        Movie(
            "Night of the Living Dead", "1968", "Terror",
            "Um grupo de pessoas tenta sobreviver durante uma noite cercada por mortos-vivos.",
            "https://archive.org/download/night_of_the_living_dead/night_of_the_living_dead_512kb.mp4",
            "🧟",
            "Frequentemente distribuído como domínio público nos EUA; confirme a situação jurídica local."
        ),
        Movie(
            "His Girl Friday", "1940", "Comédia",
            "Uma jornalista tenta equilibrar sua carreira, um antigo amor e uma grande notícia.",
            "https://archive.org/download/his_girl_friday/his_girl_friday_512kb.mp4",
            "🎬",
            "A situação de direitos pode variar por país; confirme antes de redistribuir."
        ),
        Movie(
            "The General", "1926", "Aventura",
            "Um maquinista embarca numa perseguição durante a Guerra Civil Americana.",
            "https://archive.org/download/TheGeneral1926_201610/TheGeneral1926_512kb.mp4",
            "🚂",
            "Filme mudo antigo; confirme direitos da cópia e trilha sonora utilizada."
        ),
        Movie(
            "A Trip to the Moon", "1902", "Fantasia",
            "Uma expedição fantástica viaja até a Lua, num clássico pioneiro do cinema.",
            "https://archive.org/download/Levoyagedanslalune/LeVoyagedanslalune.mp4",
            "🌙",
            "A obra original é antiga; confirme direitos da restauração e do arquivo específico."
        )
    )
}
