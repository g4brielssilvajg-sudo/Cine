package br.com.cinelivre

import android.graphics.Color
import android.os.Bundle
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.exoplayer2.MediaItem
import com.google.android.exoplayer2.SimpleExoPlayer
import com.google.android.exoplayer2.ui.PlayerView

class PlayerActivity : AppCompatActivity() {
    private var player: SimpleExoPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val title = intent.getStringExtra("title") ?: Catalog.items.first().title
        val movie = Catalog.items.firstOrNull { it.title == title } ?: Catalog.items.first()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
        }
        root.addView(TextView(this).apply {
            text = movie.title
            textSize = 20f
            setTextColor(Color.WHITE)
            setPadding(16, 18, 16, 18)
        })
        val playerView = PlayerView(this)
        root.addView(playerView, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 260
        ))
        root.addView(TextView(this).apply {
            text = "Se o vídeo não carregar, o link de demonstração pode estar indisponível."
            textSize = 13f
            setTextColor(Color.LTGRAY)
            setPadding(16, 16, 16, 16)
        })
        setContentView(root)

        player = SimpleExoPlayer.Builder(this).build().also { exo ->
            playerView.player = exo
            exo.setMediaItem(MediaItem.fromUri(movie.videoUrl))
            exo.prepare()
            exo.playWhenReady = true
        }
    }

    override fun onStop() {
        super.onStop()
        player?.release()
        player = null
    }
}
